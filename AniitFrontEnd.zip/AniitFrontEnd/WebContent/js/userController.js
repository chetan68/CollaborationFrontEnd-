app.controller('UserController',function($scope,UserService){
	console.log('entering the controller')
	$scope.users = [];
	
	$scope.user = {
			userid : 10,
			fullname : 'amit',
			address : 'ahmedabad',
			email : '',
			mobile : '',
			dob : '',
			gender : '',
			username : '',
			password : '',
			roleid : null,
			reason : '',
			status : '',
			isonline : ''
		};
	
	
	//this function will not be called by any HTML page
	function fetchAllUsers(){
		console.log('entering fetchall user in controller')
		UserService.fetchAllUsers().then(
				function(d){
					$scope.userss=d;
				},
				function(error){
					console.log(error);
				}
		)
	}

	fetchAllUsers();
	$scope.save=function(){
		console.log('entering the function save in user controller')
		
		console.log($scope.user.fullname)
		console.log($scope.user.email)
		console.log($scope.user.address)
		UserService.saveUser($scope.user).then(
		function(d){
			console.log(d.status)
			fetchAllUsers();
			$location.path('/listOfUsers');
		}	,
		function(d){
			console.log(d.status)
			$scope.status="Unable to insert user details";
		}
		);
	}

	$scope.deleteUser=function(id){
		console.log("entering delete in controller with id"+id)
		UserService.deleteUser(id)
		.then(
				function(d){
			console.log('deleted successfully')
			console.log(d)
			fetchAllUsers();
			$location.path('/listOfUsers')
		},function(){
			console.log("unable to delete the record")
		})
	}
	
	
	
})
var app=angular.module('myApp',['ngRoute'])
app.config(function($routeProvider){
	console.log('Entering app configuration')

	$routeProvider
	.when('/register',{
		controller:'UserController',
		templateUrl:'pages/register.html'
	})
	.when('/listOfUsers',{
		controller:'UserController',
		templateUrl:'pages/listOfUsers.html'
	})
	
	.when('/',{templateUrl:'pages/home.html'})
})
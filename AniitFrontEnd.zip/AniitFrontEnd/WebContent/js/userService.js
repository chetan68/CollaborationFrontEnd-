app.factory('UserService',function($http){
	var BASE_URL="http://localhost:8081/Aniit"; 
	var userService=this;
	userService.fetchAllUsers=function(){
		console.log('entering fetchalluser in service')
	
		return $http.get("http://localhost:8081/Aniit/users")
		.then(function(response){
			
			console.log(response.data)
			console.log(response.status)
			return response.data
			
		},
		function(response){
			console.log(response.data)
			return response.data
		})
	};
	
	userService.saveUser=function(user){
		console.log('entering save user in service')
		 return $http.post(BASE_URL + "/users",user)
		.then(function(response){
			console.log(response.status)
			console.log(response.headers.location)
			return response.status
		},function(reponse){
			console.log(response.status)
			return response.status
		})
	}
	userService.deleteUser=function(id){
		console.log("entering delete user in service with id"+id);
		return $http.delete(BASE_URL+"/users/"+id)
		.then(function(response){
			console.log(response.status)
			return response.status;
		},function(response){
			console.log(response.status)
		});
	};
	
	userService.getUser=function(id){
		return $http.get(BASE_URL+"/users/"+id)
	};
	
	userService.updateUser=function(userId,user){
		console.log('update user in service')
		console.log('user id'+userId)
		return $http.put(BASE_URL+"/users/"+userId,user);
	}
	
	return userService;

})